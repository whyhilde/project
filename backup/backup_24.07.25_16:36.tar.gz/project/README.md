# Project

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.
