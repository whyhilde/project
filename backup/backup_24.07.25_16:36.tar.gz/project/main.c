// Copyright (c) 2025 whyhilde, sakuyma1337
// SPDX-License-Identifier: MIT


#include "include/config.h"

int main()
{
  INIT();

  return 0;
}
